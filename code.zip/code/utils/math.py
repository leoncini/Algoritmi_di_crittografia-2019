"""
Created on Fri March 8 8:56:54 2019

@author: Mauro Leoncini
"""

import pdb
def derangement(n):
    '''A simple algorithm to find a random derangement of the
       set {0,1,...,n-1}
    '''
    from random import randint
    assert n>=2
    d = {}
    S = set([i for i in range(n)])
    last = n-1
    secondlast = n-2
    for i in range(n-2):
        j = randint(0,n-1-i)
        while list(S)[j] == i: # no element can appear in its original position
            j = randint(0,n-1-i) # retry
        d[i] = list(S)[j]
        S = S.difference(set([d[i]])) # remove the image of i from set
    # If only 9 remained in the set we would be in troubles, 
    # hence we make a control one step before
    if secondlast in S and last in S:
        d[secondlast] = last
        d[last] = secondlast
    elif secondlast in S:
        S.discard(secondlast)
        d[secondlast] = list(S)[0]
        d[last] = secondlast
    elif last in S:
        S.discard(last)
        d[secondlast] = last
        d[last] = list(S)[0]
    else:
        j = randint(0,1)
        d[secondlast] = list(S)[j]
        d[last] = list(S)[1-j]
    return d

def RandPerm(n,others=[]):
    ''' Computes and returns a random permutation P of {0, ..., n-1}.
        others may be a list of other permutations. In this case,
        for no p in others will hold that P[i]==p[i], i = 0, ..., n-1.
        We say that P does not collide with the permutations in others.
    '''
    from os import urandom
    rand = lambda n: int.from_bytes(urandom(1),byteorder='big')%n
    P = {}
    def stuck(i, remaining):
        ''' The algorithm might be forced to backtrack if all the
            remaining values at step i cannot lead to a 
            permutation that satisfy the requirements (i.e. of
            having no collision with the permutations in others)
        '''
        return len(others)>=n-i and \
                remaining.difference(set([p[i] for p in others]))==set()
    def usable(x, i, remaining):
        ''' A value x is usable at step i if it's not been generated yet
            and does not collide with other permutations.
        '''
        return x in remaining and not(x in [p[i] for p in others])

    # Not quite pythonic a code, yet it works ...
    done = False
    while not done:
        done = True
        remaining = set(range(n))
        for i in range(n):
            if stuck(i,remaining):
                done = False
                break
            x = rand(n)
            while not usable(x, i, remaining):
                x = rand(n)
            P[i] = x
            remaining = remaining.difference({x})
    return P

def InversePerm(P):
    invP = {}
    for k,v in P.items():
        invP[v] = k
    return invP

def perm(bits,P):
    from bitarray import bitarray
    ''' Reorders bits according to permutation P '''
    pbits = bitarray(endian='big')
    for p in sorted(P.items(), key=lambda pair: pair[1]):
        pbits.append(bits[p[0]])
    return pbits
